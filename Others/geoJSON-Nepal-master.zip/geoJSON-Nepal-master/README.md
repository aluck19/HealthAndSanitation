geoJSON-Nepal
=============

Valid geoJSON for Nepal - districts and development regions.